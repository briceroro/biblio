package com.mairie.biblio.biblioWebservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BiblioWebserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BiblioWebserviceApplication.class, args);
	}

}
